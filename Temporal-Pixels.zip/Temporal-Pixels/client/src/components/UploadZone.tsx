import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Upload, Lock, Clock, Image as ImageIcon, X, AlertTriangle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export function UploadZone() {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [description, setDescription] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const unlockDate = new Date();
  unlockDate.setFullYear(unlockDate.getFullYear() + 10);

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("No file selected");
      
      const formData = new FormData();
      formData.append("photo", file);
      if (description) formData.append("description", description);
      
      const response = await fetch("/api/photos/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("401: Unauthorized");
        }
        throw new Error("Upload failed");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos/my"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setFile(null);
      setPreview(null);
      setDescription("");
      setShowConfirmDialog(false);
      toast({
        title: "Photo verrouillée !",
        description: `Votre photo sera dévoilée le ${unlockDate.toLocaleDateString('fr-FR')}.`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Non autorisé",
          description: "Vous devez vous reconnecter.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible d'uploader la photo.",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = useCallback((selectedFile: File | null) => {
    if (selectedFile && selectedFile.type.startsWith("image/")) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(selectedFile);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    handleFileChange(droppedFile);
  }, [handleFileChange]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const clearFile = () => {
    setFile(null);
    setPreview(null);
    setDescription("");
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Uploader une photo
          </CardTitle>
          <CardDescription>
            Votre photo sera verrouillée pendant 10 ans avant d'être révélée au monde
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!file ? (
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`
                relative border-2 border-dashed rounded-lg min-h-64 
                flex flex-col items-center justify-center gap-4 p-8
                transition-colors cursor-pointer
                ${isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50"}
              `}
            >
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                data-testid="input-file-upload"
              />
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                <ImageIcon className="h-8 w-8 text-muted-foreground" />
              </div>
              <div className="text-center">
                <p className="font-medium mb-1">
                  Glissez-déposez une image ici
                </p>
                <p className="text-sm text-muted-foreground">
                  ou cliquez pour sélectionner un fichier
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                PNG, JPG, GIF jusqu'à 10MB
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                <img
                  src={preview!}
                  alt="Aperçu"
                  className="w-full h-full object-contain"
                />
                <Button
                  size="icon"
                  variant="destructive"
                  className="absolute top-2 right-2"
                  onClick={clearFile}
                  data-testid="button-clear-file"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description (optionnelle)</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ajoutez un message à votre futur vous..."
                  className="resize-none"
                  data-testid="input-photo-description"
                />
              </div>

              <Card className="bg-muted/50">
                <CardContent className="py-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Lock className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium mb-1">Cette photo sera verrouillée</p>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="font-mono">
                          <Clock className="h-3 w-3 mr-1" />
                          10 ans
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          Déverrouillage le{" "}
                          <span className="font-mono">{unlockDate.toLocaleDateString('fr-FR')}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button
                size="lg"
                className="w-full"
                onClick={() => setShowConfirmDialog(true)}
                disabled={uploadMutation.isPending}
                data-testid="button-upload-photo"
              >
                <Lock className="h-5 w-5 mr-2" />
                {uploadMutation.isPending ? "Envoi en cours..." : "Verrouiller cette photo"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Confirmer le verrouillage
            </DialogTitle>
            <DialogDescription>
              Cette action est irréversible. Une fois verrouillée, votre photo ne pourra plus être vue jusqu'au{" "}
              <strong className="font-mono">{unlockDate.toLocaleDateString('fr-FR')}</strong>.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {preview && (
              <div className="aspect-video rounded-lg overflow-hidden bg-muted mb-4">
                <img
                  src={preview}
                  alt="Aperçu"
                  className="w-full h-full object-contain"
                />
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              Êtes-vous sûr de vouloir verrouiller cette photo pendant 10 ans ?
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
              disabled={uploadMutation.isPending}
              data-testid="button-cancel-upload"
            >
              Annuler
            </Button>
            <Button
              onClick={() => uploadMutation.mutate()}
              disabled={uploadMutation.isPending}
              data-testid="button-confirm-upload"
            >
              <Lock className="h-4 w-4 mr-2" />
              {uploadMutation.isPending ? "Verrouillage..." : "Confirmer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
