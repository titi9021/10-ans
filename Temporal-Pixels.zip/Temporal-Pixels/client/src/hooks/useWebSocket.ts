import { useEffect, useRef, useCallback, useState } from "react";
import type { ChatMessageWithUser } from "@shared/schema";

interface WebSocketMessage {
  type: "chat" | "userCount" | "history";
  data?: ChatMessageWithUser;
  messages?: ChatMessageWithUser[];
  count?: number;
}

export function useWebSocket() {
  const socketRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<ChatMessageWithUser[]>([]);
  const [onlineCount, setOnlineCount] = useState(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setIsConnected(true);
    };

    socket.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        
        if (message.type === "history" && message.messages) {
          setMessages(message.messages);
        } else if (message.type === "chat" && message.data) {
          setMessages((prev) => [...prev, message.data!]);
        } else if (message.type === "userCount" && message.count !== undefined) {
          setOnlineCount(message.count);
        }
      } catch (error) {
        console.error("Failed to parse WebSocket message:", error);
      }
    };

    socket.onclose = () => {
      setIsConnected(false);
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 3000);
    };

    socket.onerror = () => {
      socket.close();
    };

    socketRef.current = socket;
  }, []);

  const sendMessage = useCallback((content: string) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      // Server uses session-based authentication, no need to send userId
      socketRef.current.send(JSON.stringify({ type: "chat", content }));
    }
  }, []);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    socketRef.current?.close();
  }, []);

  useEffect(() => {
    connect();
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    isConnected,
    messages,
    onlineCount,
    sendMessage,
  };
}
