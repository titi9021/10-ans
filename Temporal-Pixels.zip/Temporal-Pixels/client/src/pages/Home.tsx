import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Lock, 
  Upload, 
  Image as ImageIcon, 
  MessageCircle, 
  Settings, 
  LogOut,
  Clock,
  Eye,
  Trash2,
  Users,
  X
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Photo, PhotoWithUser } from "@shared/schema";
import { ChatPanel } from "@/components/ChatPanel";
import { UploadZone } from "@/components/UploadZone";
import { SettingsPanel } from "@/components/SettingsPanel";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("upload");
  const [isChatOpen, setIsChatOpen] = useState(false);

  const { data: myPhotos, isLoading: photosLoading } = useQuery<Photo[]>({
    queryKey: ["/api/photos/my"],
  });

  const { data: publicPhotos } = useQuery<PhotoWithUser[]>({
    queryKey: ["/api/photos/public"],
  });

  const deletePhotoMutation = useMutation({
    mutationFn: async (photoId: string) => {
      await apiRequest("DELETE", `/api/photos/${photoId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos/my"] });
      toast({
        title: "Photo supprimée",
        description: "Votre photo a été supprimée avec succès.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Non autorisé",
          description: "Vous devez vous reconnecter.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la photo.",
        variant: "destructive",
      });
    },
  });

  const getTimeRemaining = (unlockAt: Date) => {
    const now = new Date();
    const unlock = new Date(unlockAt);
    const diff = unlock.getTime() - now.getTime();
    
    if (diff <= 0) return "Déverrouillée";
    
    const years = Math.floor(diff / (1000 * 60 * 60 * 24 * 365));
    const months = Math.floor((diff % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24 * 30));
    const days = Math.floor((diff % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24));
    
    if (years > 0) {
      return `${years}a ${months}m ${days}j`;
    } else if (months > 0) {
      return `${months}m ${days}j`;
    } else {
      return `${days}j`;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Lock className="h-6 w-6 text-primary" />
            <span className="font-semibold text-xl tracking-tight">TimeCapsule</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="ghost"
              className="relative md:hidden"
              onClick={() => setIsChatOpen(true)}
              data-testid="button-open-chat-mobile"
            >
              <MessageCircle className="h-5 w-5" />
            </Button>
            <ThemeToggle />
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback>
                  {user?.firstName?.[0] || user?.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline text-sm font-medium">
                {user?.firstName || user?.email?.split("@")[0]}
              </span>
            </div>
            <Button variant="ghost" size="icon" asChild data-testid="button-logout">
              <a href="/api/logout">
                <LogOut className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        <main className="flex-1 overflow-hidden">
          <div className="max-w-5xl mx-auto p-4 md:p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="upload" data-testid="tab-upload">
                  <Upload className="h-4 w-4 mr-2" />
                  Uploader
                </TabsTrigger>
                <TabsTrigger value="my-photos" data-testid="tab-my-photos">
                  <ImageIcon className="h-4 w-4 mr-2" />
                  Mes photos
                </TabsTrigger>
                <TabsTrigger value="gallery" data-testid="tab-gallery">
                  <Eye className="h-4 w-4 mr-2" />
                  Galerie
                </TabsTrigger>
                <TabsTrigger value="settings" data-testid="tab-settings">
                  <Settings className="h-4 w-4 mr-2" />
                  Paramètres
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="m-0">
                <UploadZone />
              </TabsContent>

              <TabsContent value="my-photos" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Lock className="h-5 w-5" />
                      Mes photos en attente
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {photosLoading ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="aspect-square bg-muted animate-pulse rounded-lg" />
                        ))}
                      </div>
                    ) : !myPhotos || myPhotos.length === 0 ? (
                      <div className="text-center py-12">
                        <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="font-semibold mb-2">Aucune photo</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Vous n'avez pas encore uploadé de photos.
                        </p>
                        <Button onClick={() => setActiveTab("upload")} data-testid="button-upload-first">
                          <Upload className="h-4 w-4 mr-2" />
                          Uploader ma première photo
                        </Button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {myPhotos.map((photo) => (
                          <Card key={photo.id} className="overflow-hidden group relative" data-testid={`card-photo-${photo.id}`}>
                            <div className="aspect-square relative bg-muted">
                              <div className="absolute inset-0 flex items-center justify-center bg-muted">
                                <div className="text-center p-4">
                                  <Lock className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                                  <Badge variant="secondary" className="font-mono text-xs">
                                    <Clock className="h-3 w-3 mr-1" />
                                    {getTimeRemaining(photo.unlockAt)}
                                  </Badge>
                                </div>
                              </div>
                              <Button
                                size="icon"
                                variant="destructive"
                                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => deletePhotoMutation.mutate(photo.id)}
                                disabled={deletePhotoMutation.isPending}
                                data-testid={`button-delete-photo-${photo.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                            <div className="p-3 border-t">
                              <p className="text-xs text-muted-foreground font-mono">
                                Uploadée le {new Date(photo.uploadedAt).toLocaleDateString('fr-FR')}
                              </p>
                              <p className="text-xs text-muted-foreground font-mono">
                                Déverrouillage le {new Date(photo.unlockAt).toLocaleDateString('fr-FR')}
                              </p>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="gallery" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="h-5 w-5" />
                      Photos déverrouillées
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!publicPhotos || publicPhotos.length === 0 ? (
                      <div className="text-center py-12">
                        <Lock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="font-semibold mb-2">Aucune photo déverrouillée</h3>
                        <p className="text-sm text-muted-foreground">
                          Les premières photos seront révélées en {new Date().getFullYear() + 10}.
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {publicPhotos.map((photo) => (
                          <Card key={photo.id} className="overflow-hidden group" data-testid={`card-public-photo-${photo.id}`}>
                            <div className="aspect-square relative">
                              <img
                                src={`/api/photos/serve/${photo.id}`}
                                alt={photo.description || "Photo déverrouillée"}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="absolute bottom-0 left-0 right-0 p-3">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Avatar className="h-5 w-5">
                                      <AvatarImage src={photo.user.profileImageUrl || undefined} />
                                      <AvatarFallback className="text-xs">
                                        {photo.user.firstName?.[0] || "U"}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span className="text-white text-xs">
                                      {photo.user.firstName || "Anonyme"}
                                    </span>
                                  </div>
                                  <p className="text-white/80 text-xs font-mono">
                                    Déverrouillée le {new Date(photo.unlockAt).toLocaleDateString('fr-FR')}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="m-0">
                <SettingsPanel />
              </TabsContent>
            </Tabs>
          </div>
        </main>

        <aside className="hidden md:block w-80 border-l bg-sidebar">
          <ChatPanel />
        </aside>
      </div>

      {isChatOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div 
            className="absolute inset-0 bg-black/50" 
            onClick={() => setIsChatOpen(false)}
          />
          <div className="absolute right-0 top-0 bottom-0 w-full max-w-sm bg-sidebar">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="font-semibold flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Chat en direct
              </h2>
              <Button 
                size="icon" 
                variant="ghost" 
                onClick={() => setIsChatOpen(false)}
                data-testid="button-close-chat"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
            <ChatPanel />
          </div>
        </div>
      )}
    </div>
  );
}
