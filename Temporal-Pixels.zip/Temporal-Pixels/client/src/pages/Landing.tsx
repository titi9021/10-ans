import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Lock, Clock, Eye, Upload, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Landing() {
  const { data: stats } = useQuery<{ totalPhotos: number; nextUnlock: string | null }>({
    queryKey: ["/api/stats"],
  });

  const nextUnlockYear = stats?.nextUnlock 
    ? new Date(stats.nextUnlock).getFullYear() 
    : new Date().getFullYear() + 10;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Lock className="h-6 w-6 text-primary" />
            <span className="font-semibold text-xl tracking-tight">TimeCapsule</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Se connecter</a>
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
          <div 
            className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/30"
            aria-hidden="true"
          />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent" />
          
          <div className="relative z-10 max-w-4xl mx-auto px-4 py-16 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted mb-8">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-mono text-muted-foreground">
                {stats?.totalPhotos || 0} photos en attente de déverrouillage
              </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Vos souvenirs,{" "}
              <span className="text-primary">dévoilés dans 10 ans</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
              Uploadez une photo aujourd'hui. Elle restera cachée pendant 10 ans, 
              puis sera révélée au monde entier. Une capsule temporelle numérique 
              pour les générations futures.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild data-testid="button-start-capsule">
                <a href="/api/login">
                  <Upload className="mr-2 h-5 w-5" />
                  Créer ma capsule
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-gallery">
                <a href="#gallery">
                  <Eye className="mr-2 h-5 w-5" />
                  Voir la galerie
                </a>
              </Button>
            </div>

            <p className="mt-8 text-sm text-muted-foreground font-mono">
              Prochaine révélation en {nextUnlockYear}
            </p>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-muted/30">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-semibold text-center mb-12">
              Comment ça fonctionne
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="text-center">
                <CardContent className="pt-8 pb-6 px-6">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <Upload className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-3">1. Uploadez</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Choisissez une photo qui représente un moment important. 
                    Elle sera stockée en toute sécurité.
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-8 pb-6 px-6">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <Lock className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-3">2. Attendez 10 ans</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Votre photo reste verrouillée et invisible pour tous, 
                    même pour vous. Patience...
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-8 pb-6 px-6">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <Eye className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-3">3. Révélation</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Après 10 ans, votre photo est dévoilée dans la galerie 
                    publique pour le monde entier.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="gallery" className="py-16 md:py-24">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-semibold text-center mb-4">
              Galerie des souvenirs dévoilés
            </h2>
            <p className="text-center text-muted-foreground mb-12 max-w-xl mx-auto">
              Ces photos ont attendu 10 ans pour être révélées au monde
            </p>
            
            <PublicGalleryPreview />
          </div>
        </section>

        <section className="py-16 md:py-24 bg-primary/5">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <Users className="h-12 w-12 text-primary mx-auto mb-6" />
            <h2 className="text-2xl md:text-3xl font-semibold mb-4">
              Rejoignez les voyageurs du temps
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Des milliers de personnes ont déjà déposé leurs souvenirs dans notre capsule temporelle. 
              Faites partie de l'histoire.
            </p>
            <Button size="lg" asChild data-testid="button-join">
              <a href="/api/login">Créer mon compte</a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>TimeCapsule - Vos souvenirs traversent le temps</p>
        </div>
      </footer>
    </div>
  );
}

function PublicGalleryPreview() {
  const { data: photos, isLoading } = useQuery<any[]>({
    queryKey: ["/api/photos/public"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="aspect-square bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (!photos || photos.length === 0) {
    return (
      <Card className="max-w-md mx-auto">
        <CardContent className="py-12 text-center">
          <Lock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold mb-2">Aucune photo déverrouillée</h3>
          <p className="text-sm text-muted-foreground">
            Les premières photos seront révélées en {new Date().getFullYear() + 10}. 
            Soyez patient...
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {photos.slice(0, 8).map((photo) => (
        <Card key={photo.id} className="overflow-hidden group">
          <div className="aspect-square relative">
            <img
              src={`/api/photos/serve/${photo.id}`}
              alt={photo.description || "Photo déverrouillée"}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <p className="text-white text-xs font-mono">
                  Déverrouillée le {new Date(photo.unlockAt).toLocaleDateString('fr-FR')}
                </p>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
