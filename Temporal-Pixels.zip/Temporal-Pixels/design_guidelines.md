# Design Guidelines: Time Capsule Photo Platform

## Design Approach

**Reference-Based Approach** drawing from:
- Instagram/Pinterest for photo gallery patterns
- Archive.org for temporal, archival aesthetics
- Notion for clean, modern interface elements
- Discord for real-time chat integration

**Core Concept**: Balance modern usability with a nostalgic, mysterious "time capsule" aesthetic that emphasizes the 10-year temporal lock.

## Typography

**Font Stack**:
- Primary: "Inter" (clean, modern readability)
- Accent: "Space Mono" (monospaced for dates/timestamps, reinforcing the "time" theme)

**Hierarchy**:
- Hero/Main Headlines: 3xl-4xl, font-bold, tracking-tight
- Section Headers: 2xl, font-semibold
- Body Text: base, font-normal, leading-relaxed
- Timestamps/Metadata: sm, font-mono, tracking-wide
- Chat Messages: sm, font-normal

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 8, 12, 16 for consistent rhythm
- Component padding: p-4 to p-8
- Section spacing: py-12 to py-16
- Grid gaps: gap-4 to gap-8

**Container Strategy**:
- Max-width: max-w-7xl for main content
- Photo grids: max-w-6xl
- Chat sidebar: Fixed 320px width on desktop

## Core Pages & Layouts

### Landing Page (Public)
**Hero Section** (70vh):
- Large background image showing a vintage camera or hourglass (blurred, subtle)
- Centered content with main headline explaining the 10-year concept
- Primary CTA: "Start Your Time Capsule" button with blurred background
- Subtext: Dynamic counter showing "X photos waiting to unlock in [year]"

**How It Works Section**:
- 3-column grid (lg:grid-cols-3) with icons
- Upload → Wait 10 Years → Reveal
- Each column with icon, title, and brief description

**Public Gallery Preview**:
- Masonry grid layout (2-4 columns based on viewport)
- Shows unlocked photos with unlock dates
- Empty state if no photos unlocked: "The first photos will unlock in [year]. Be patient..."

**CTA Section**: 
- "Create Your Account" with social proof ("Join X time travelers")

### Authentication
- Clean, centered modal overlay
- Replit Auth integration (Google, GitHub, email)
- Minimal form design with clear labels

### Dashboard (Authenticated Users)
**Layout**: Split-screen on desktop
- Left: Main content area (upload, galleries, settings)
- Right: Fixed chat sidebar (320px)
- Mobile: Bottom navigation with chat as separate view

**Upload Interface**:
- Large, dashed-border drop zone (min-h-64)
- Preview of uploaded image with metadata
- Prominent "Lock Until [Year+10]" indicator with lock icon
- Confirmation modal emphasizing 10-year wait

**My Uploads Section**:
- Grid of user's uploaded photos with status indicators:
  - "Locked" badge with countdown (Years/Months/Days remaining)
  - Blurred thumbnail or lock icon overlay
  - Upload date in monospace font

### Public Gallery (Full Page)
- Masonry grid (Pinterest-style) with responsive columns
- Each photo card includes:
  - Full photo display
  - "Unlocked on [date]" timestamp
  - Uploader username
  - Like/comment count (optional)
- Infinite scroll or pagination
- Empty state: Elegant illustration with "Nothing unlocked yet. Check back in [next unlock year]"

### Real-Time Chat
**Desktop**: Fixed right sidebar
- Header: "Live Chat" with online user count
- Messages: Compact bubbles with username and timestamp
- Input: Bottom-fixed with send button
- Auto-scroll to latest

**Mobile**: Full-screen overlay or bottom sheet
- Floating action button to open chat
- Same message layout, optimized for mobile

### Settings Page
- Clean, card-based layout
- Sections: Account Info, Security, Preferences
- Forms with clear labels and validation
- Logout button (destructive action, red accent)

## Component Library

**Photo Cards**:
- Rounded corners (rounded-lg)
- Subtle shadow (shadow-md)
- Hover lift effect (minimal transform)
- Lock overlay for unreleased photos: semi-transparent with centered lock icon and countdown

**Buttons**:
- Primary: Solid with rounded-lg, px-6 py-3
- Secondary: Outlined variant
- Blurred background when over images
- No custom hover states (use default)

**Forms**:
- Input fields: border, rounded-md, p-3
- Labels: font-medium, mb-2
- Validation: Red border for errors, green for success

**Chat Components**:
- Message bubbles: Own messages aligned right, others left
- Compact padding (px-3 py-2)
- Username in smaller, muted font
- Timestamp: xs, monospace, muted

**Status Indicators**:
- Lock icon for unreleased photos
- Countdown timer in monospace font
- Badge components for "Locked" / "Unlocked" states

## Images

**Hero Image**: Vintage camera, hourglass, or abstract time concept - blurred, atmospheric
**How It Works Icons**: Upload cloud, hourglass/clock, eye/reveal symbol
**Empty States**: Illustration of locked vault or calendar
**Gallery**: User-uploaded photos (actual content)

## Visual Principles

- **Temporal Emphasis**: Use countdown timers, lock icons, and date displays prominently
- **Mystery & Anticipation**: Blurred thumbnails, lock overlays create intrigue
- **Clean Navigation**: Clear hierarchy between upload, gallery, chat, settings
- **Responsive**: Mobile-first with thoughtful desktop enhancements (chat sidebar)
- **Performance**: Lazy load gallery images, optimize uploads