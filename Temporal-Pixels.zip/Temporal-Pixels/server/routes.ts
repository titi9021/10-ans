import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, getSession } from "./replitAuth";
import type { ChatMessageWithUser } from "@shared/schema";
import type { IncomingMessage } from "http";

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadsDir,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${randomUUID()}${ext}`);
    },
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);

  // Secure file serving - only serve unlocked photos
  // Public access allowed since only unlocked photos can be served
  // and locked photo IDs are never exposed in API responses
  app.get("/api/photos/serve/:id", async (req: any, res) => {
    try {
      const photoId = req.params.id;
      const photo = await storage.getPhotoById(photoId);
      
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      
      // Check if photo is unlocked (10 years have passed)
      const now = new Date();
      if (new Date(photo.unlockAt) > now) {
        return res.status(403).json({ message: "This photo is still locked" });
      }
      
      const filePath = path.join(uploadsDir, photo.filename);
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.sendFile(filePath);
    } catch (error) {
      console.error("Error serving file:", error);
      res.status(500).json({ message: "Failed to serve file" });
    }
  });
  
  // Block direct access to uploads directory
  app.use("/uploads", (req, res) => {
    res.status(403).json({ message: "Direct access forbidden" });
  });

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const photos = await storage.getUnlockedPhotos();
      const nextUnlock = null;
      res.json({
        totalPhotos: photos.length,
        nextUnlock,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/photos/public", async (req, res) => {
    try {
      await storage.updateUnlockedStatus();
      const photos = await storage.getUnlockedPhotos();
      res.json(photos);
    } catch (error) {
      console.error("Error fetching public photos:", error);
      res.status(500).json({ message: "Failed to fetch photos" });
    }
  });

  app.get("/api/photos/my", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const photos = await storage.getPhotosByUser(userId);
      // Owners can see their own photo IDs for management (deletion)
      // but filenames are removed from locked photos to prevent early access
      const sanitizedPhotos = photos.map((photo) => {
        const now = new Date();
        const isUnlocked = new Date(photo.unlockAt) <= now;
        return {
          id: photo.id, // Owner can see ID for deletion purposes
          userId: photo.userId,
          uploadedAt: photo.uploadedAt,
          unlockAt: photo.unlockAt,
          isUnlocked,
          description: isUnlocked ? photo.description : null,
          // Only include filename and originalName if unlocked
          ...(isUnlocked ? { 
            filename: photo.filename, 
            originalName: photo.originalName,
            mimeType: photo.mimeType
          } : {})
        };
      });
      res.json(sanitizedPhotos);
    } catch (error) {
      console.error("Error fetching user photos:", error);
      res.status(500).json({ message: "Failed to fetch photos" });
    }
  });

  app.post(
    "/api/photos/upload",
    isAuthenticated,
    upload.single("photo"),
    async (req: any, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }

        const userId = req.user.claims.sub;
        const photo = await storage.createPhoto({
          userId,
          filename: req.file.filename,
          originalName: req.file.originalname,
          mimeType: req.file.mimetype,
          description: req.body.description || null,
        });

        res.json(photo);
      } catch (error) {
        console.error("Error uploading photo:", error);
        res.status(500).json({ message: "Failed to upload photo" });
      }
    }
  );

  app.delete("/api/photos/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const photoId = req.params.id;

      const photo = await storage.getPhotoById(photoId);
      if (photo && photo.filename) {
        const filePath = path.join(uploadsDir, photo.filename);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }

      const deleted = await storage.deletePhoto(photoId, userId);
      if (!deleted) {
        return res.status(404).json({ message: "Photo not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting photo:", error);
      res.status(500).json({ message: "Failed to delete photo" });
    }
  });

  interface AuthenticatedWebSocket extends WebSocket {
    userId?: string;
  }
  
  const clients = new Map<WebSocket, string>(); // Map socket to userId
  const sessionMiddleware = getSession();

  // Helper to parse session and get userId
  const parseSession = (req: IncomingMessage): Promise<string | null> => {
    return new Promise((resolve) => {
      const mockRes = { 
        setHeader: () => {}, 
        getHeader: () => undefined 
      } as any;
      
      sessionMiddleware(req as any, mockRes, () => {
        const session = (req as any).session;
        const user = session?.passport?.user;
        resolve(user?.claims?.sub || null);
      });
    });
  };

  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: "/ws",
    // Verify client before accepting connection
    verifyClient: async (info, callback) => {
      try {
        const userId = await parseSession(info.req);
        if (userId) {
          (info.req as any).userId = userId;
          callback(true);
        } else {
          callback(false, 401, "Authentication required");
        }
      } catch (error) {
        callback(false, 500, "Session error");
      }
    }
  });

  const broadcastUserCount = () => {
    const count = clients.size;
    const message = JSON.stringify({ type: "userCount", count });
    clients.forEach((userId, client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  wss.on("connection", async (ws: AuthenticatedWebSocket, req: IncomingMessage) => {
    // At this point, connection is already verified as authenticated
    const userId = (req as any).userId as string;
    ws.userId = userId;
    clients.set(ws, userId);
    broadcastUserCount();

    try {
      const messages = await storage.getRecentMessages(50);
      ws.send(JSON.stringify({ type: "history", messages }));
    } catch (error) {
      console.error("Error fetching chat history:", error);
    }

    ws.on("message", async (data) => {
      try {
        if (!ws.userId) {
          ws.send(JSON.stringify({ type: "error", message: "Authentication required" }));
          return;
        }

        const parsed = JSON.parse(data.toString());
        
        // Use server-side userId, ignore client-supplied userId
        if (parsed.type === "chat" && parsed.content) {
          const messageWithUser = await storage.createChatMessage({
            userId: ws.userId,
            content: parsed.content.substring(0, 1000), // Limit message length
          });

          const broadcast = JSON.stringify({ type: "chat", data: messageWithUser });
          clients.forEach((uid, client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(broadcast);
            }
          });
        }
      } catch (error) {
        console.error("Error handling WebSocket message:", error);
      }
    });

    ws.on("close", () => {
      clients.delete(ws);
      broadcastUserCount();
    });

    ws.on("error", () => {
      clients.delete(ws);
      broadcastUserCount();
    });
  });

  return httpServer;
}
