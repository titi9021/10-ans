import {
  users,
  photos,
  chatMessages,
  type User,
  type UpsertUser,
  type Photo,
  type InsertPhoto,
  type ChatMessage,
  type InsertChatMessage,
  type PhotoWithUser,
  type ChatMessageWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, lte, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Photo operations
  createPhoto(photo: InsertPhoto): Promise<Photo>;
  getPhotoById(id: string): Promise<Photo | undefined>;
  getPhotoByFilename(filename: string): Promise<Photo | undefined>;
  getPhotosByUser(userId: string): Promise<Photo[]>;
  getUnlockedPhotos(): Promise<PhotoWithUser[]>;
  updateUnlockedStatus(): Promise<void>;
  deletePhoto(id: string, userId: string): Promise<boolean>;
  
  // Chat operations
  createChatMessage(message: InsertChatMessage): Promise<ChatMessageWithUser>;
  getRecentMessages(limit?: number): Promise<ChatMessageWithUser[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations - mandatory for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Photo operations
  async createPhoto(photoData: InsertPhoto): Promise<Photo> {
    const uploadedAt = new Date();
    const unlockAt = new Date(uploadedAt);
    unlockAt.setFullYear(unlockAt.getFullYear() + 10);

    const [photo] = await db
      .insert(photos)
      .values({
        ...photoData,
        uploadedAt,
        unlockAt,
        isUnlocked: false,
      })
      .returning();
    return photo;
  }

  async getPhotoById(id: string): Promise<Photo | undefined> {
    const [photo] = await db.select().from(photos).where(eq(photos.id, id));
    return photo;
  }

  async getPhotoByFilename(filename: string): Promise<Photo | undefined> {
    const [photo] = await db.select().from(photos).where(eq(photos.filename, filename));
    return photo;
  }

  async getPhotosByUser(userId: string): Promise<Photo[]> {
    return await db
      .select()
      .from(photos)
      .where(eq(photos.userId, userId))
      .orderBy(desc(photos.uploadedAt));
  }

  async getUnlockedPhotos(): Promise<PhotoWithUser[]> {
    const now = new Date();
    const results = await db
      .select({
        photo: photos,
        user: users,
      })
      .from(photos)
      .innerJoin(users, eq(photos.userId, users.id))
      .where(lte(photos.unlockAt, now))
      .orderBy(desc(photos.unlockAt));

    return results.map(({ photo, user }) => ({
      ...photo,
      user,
    }));
  }

  async updateUnlockedStatus(): Promise<void> {
    const now = new Date();
    await db
      .update(photos)
      .set({ isUnlocked: true })
      .where(and(eq(photos.isUnlocked, false), lte(photos.unlockAt, now)));
  }

  async deletePhoto(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(photos)
      .where(and(eq(photos.id, id), eq(photos.userId, userId)))
      .returning();
    return result.length > 0;
  }

  // Chat operations
  async createChatMessage(messageData: InsertChatMessage): Promise<ChatMessageWithUser> {
    const [message] = await db
      .insert(chatMessages)
      .values(messageData)
      .returning();

    const user = await this.getUser(message.userId);
    return {
      ...message,
      user: user!,
    };
  }

  async getRecentMessages(limit: number = 50): Promise<ChatMessageWithUser[]> {
    const results = await db
      .select({
        message: chatMessages,
        user: users,
      })
      .from(chatMessages)
      .innerJoin(users, eq(chatMessages.userId, users.id))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);

    return results
      .map(({ message, user }) => ({
        ...message,
        user,
      }))
      .reverse();
  }
}

export const storage = new DatabaseStorage();
